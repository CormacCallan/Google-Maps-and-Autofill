<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<html>
    
    <style>
        header{
            padding: 20px;
        }
        h2{
            font-family: arial;
            color: white;
            text-align: center;
        }
        #logo{
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 25%;
            height: 25%;
            border-radius: 10px;
        }
        
    </style>
    <header>
        <img id="logo" src="img/logo.jpg">
    </header>
    
    
</html>
