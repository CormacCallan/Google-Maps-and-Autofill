<?php //$dsn = 'mysql:host=localhost;dbname=codexworld';
    //$username = 'root';
    //$password = '';

   // try {
     //   $db = new PDO($dsn, $username, $password);
    //} catch (PDOException $e) {
    //    $error_message = $e->getMessage();
   //     exit();
    //}

//Database credentials
$dbHost     = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName     = 'locations';

//Connect and select the database
try{
    $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
 
} catch (Exception $e) {
            $error_message = $e->getMessage();
       
        exit();
}
    ?>
