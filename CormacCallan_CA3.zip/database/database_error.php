<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>CA3</title>
    <link rel="stylesheet" type="text/css" href="css/main.css" />
</head>
<!-- the body section -->
<body>
    <header><h1>Locations</h1></header>
    <main>
        <h1>Database Error</h1>
        <p>There was an error connecting to the database.</p>
        <p>Check that the database is installed &amp; named correctly.</p>
        <p>Error message: <?php echo $error_message; ?></p>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> My Guitar Shop, Inc.</p>
    </footer>
</body>
</html>
